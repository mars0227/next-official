
  const page = require("./_error.original.js");
  const handlerFactory = require("next-aws-lambda");

  module.exports.render = async (event, context) => {
    const handler = handlerFactory(page);
    const responsePromise = handler(event, context);
    return responsePromise;
  };
